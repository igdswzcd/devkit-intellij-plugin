"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TreeViewProvider = exports.TreeItemNode = void 0;
const vscode_1 = require("vscode");
class TreeItemNode extends vscode_1.TreeItem {
}
exports.TreeItemNode = TreeItemNode;
class TreeViewProvider {
    getTreeItem(element) {
        return element;
    }
    getChildren(element) {
        if (element) {
            var childs = [];
            for (let index = 0; index < 1; index++) {
                let str = index.toString();
                var item = new TreeItemNode(str, vscode_1.TreeItemCollapsibleState.None);
                item.command = {
                    command: "perfadvisorTools.openChild",
                    title: "标题",
                    arguments: [str]
                };
                childs[index] = item;
            }
            return childs;
        }
        else {
            return [new TreeItemNode("root", vscode_1.TreeItemCollapsibleState.Collapsed)];
        }
    }
    getParent(element) {
        throw new Error('Method not implemented.');
    }
    resolveTreeItem(item, element, token) {
        throw new Error('Method not implemented.');
    }
}
exports.TreeViewProvider = TreeViewProvider;
//# sourceMappingURL=TreeViewProvider.js.map